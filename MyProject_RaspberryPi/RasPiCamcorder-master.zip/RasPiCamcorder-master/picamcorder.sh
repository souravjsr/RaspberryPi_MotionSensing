sleep 10
sudo python /home/pi/picamcorder2.py &
